#include "OutOfBoundsException.h"

namespace Bound
{
    std::ostream& operator<<(std::ostream& out, const Error& error)
    {
        out << error.message << " Sending you back home. " << std::endl;
        return out;
    }
}
