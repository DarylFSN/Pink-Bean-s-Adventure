#include "Score.h"

bool Score::operator>(const Score& other) const
{
    if(score > other.score)
        return true;
    return false;
}

std::ostream& operator<<(std::ostream& os, const Score& score) // Insertion operator
{
    os << std::endl  << "         " << score.name << std::string(13 - (score.name).length(), ' ') << score.date << std::string(10 - (score.date).length(), ' ') << score.score;
    return os;
}
