#ifndef Score_h
#define Score_h

#include <iostream>
#include <sstream>

struct Score
{
public:
    std::string name;
    std::string date;
    int score;
    Score(std::string name, std::string date, int score) : name(name), date(date), score(score) { }
    Score() { }
        
    bool operator>(const Score& other) const;
    friend std::ostream& operator<<(std::ostream& os, const Score& score); // Insertion operator
};

#endif /* Score_h */
