#include "TextureLoadException.h"

namespace Textures
{
    std::ostream& operator<<(std::ostream& out, const Error& error)
    {
        out << error.message << "Exiting..." << std::endl;
        return out;
    }
}
