#include "SoundLoadException.h"

namespace Sound
{
    std::ostream& operator<<(std::ostream& out, const Error& error)
    {
        out << error.message << "Exiting..." << std::endl;
        return out;
    }
}

